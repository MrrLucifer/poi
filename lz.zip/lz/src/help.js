const help = (prefix) => { 
	return `

*╭═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╮*
*║┊:* ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *      
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈  
*║┊:*   𝑁𝑎𝑚𝑎𝐵𝑜𝑡 : Lucifer BOT
*║┊:* 𝐶𝑟𝑒𝑎𝑡𝑜𝑟 : Mr.Lucifer
*║┊:* 𝑑𝑖𝑙𝑎𝑟𝑎𝑛𝑔 𝑠𝑝𝑎𝑚
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ 
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:  * ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *   
*╰═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╯*

*✧ ⃟ ⃟ ⃟━━─♡๑୨⊰᯽⊱୧๑♡─━ ⃟ ⃟ ⃟ ✧*

  █ ▄ ▄ █ ▄ █ ▄ 
█░█░█░█░█░█░█░█░█*
  █ ▀ ▀ █ ▀ █ ▀ █ ▀ █ ▀ ▀ █ ▀ 
*•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆
  █ ▄ ▄ █ ▄ █ ▄ █ ▄ █ ▄ ▄ █ ▄ 
*█░█░█░█░█░█░█░█░█*
*▌╭━⋆⃟⊱๑⋆⃟⊱๑ ˌ⃟ˌ⃟ˌ⃟ˌ‍⚔ˌ⃟ˌ⃟ˌ⃟ˌ⃟ˌ ๑⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱━╮*
*▌║*
*▌║* *${prefix}ownermenu*
*▌║* *${prefix}adminmenu*
*▌║* *${prefix}funmenu*
*▌║* *${prefix}mediamenu*
*▌║* *${prefix}kerangmenu*
*▌║* *${prefix}makermenu*
*▌║* *${prefix}othermenu*
*▌║* *${prefix}animemenu*
*▌║* *${prefix}nsfwmenu*
*▌║* *${prefix}vipmenu*
*▌║*
*▌╰━⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱  ˌ⃟ˌ⃟ˌ⃟ˌ⃟⚔ˌ⃟ˌ⃟ˌ⃟ˌˌ⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱━╯*
*█░█░█░█░█░█░█░█░█*
  █ ▀ ▀ █ ▀ █ ▀ █ ▀ █ ▀ ▀ █ ▀ 
•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆
  █ ▄ ▄ █ ▄ █ ▄ █ ▄ █ ▄ ▄ █ ▄ 
*█░█░█░█░█░█░█░█░█*
*▌*
*▌╭━⋆⃟⊱๑⋆⃟⊱๑ ˌ⃟ˌ⃟ˌ⃟ˌ‍⚔ˌ⃟ˌ⃟ˌ⃟ˌ⃟ˌ ๑⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱━╮*
*▌║*
*▌║* *${prefix}listmenu*
*▌║*
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
*▌║✙* *${prefix}bugreport*
*▌║✙*  *${prefix}info*
*▌║✙* *${prefix}owner*
*▌║*
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
*▌║*
*▌║✙* *${prefix}request*
*▌║✙* *${prefix}setprefix*
*▌║✙* *${prefix}listblock*
*▌║*
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
*▌║*
*▌║✙* *${prefix}iklan*
*▌║✙* *${prefix}runtume*
*▌║✙* *${prefix}rules*
*▌║✙* *${prefix}tnc*
*▌║✙* *${prefix}cekvip*
*▌║*
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
*▌║*
*▌║✙* *${prefix}daftarvip*
*▌║✙* *${prefix}addvip*
*▌║✙* *${prefix}dellvip*
*▌║✙* *${prefix}snk*
*▌║✙* *${prefix}listpremium*
*▌║✙* *${prefix}donate*
*▌║✙* *${prefix}fitnah*
*▌║✙* *${prefix}totaluser*
*▌║✙* *${prefix}level*
*▌║✙* *${prefix}leveling*
*▌║✙* *${prefix}addbacot*
*▌║✙* *${prefix}bacotlist*
*▌║✙* *${prefix}resetbacot*
*▌║✙* *${prefix}glass*
*▌║*
*▌╰━⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱  ˌ⃟ˌ⃟ˌ⃟ˌ⃟⚔ˌ⃟ˌ⃟ˌ⃟ˌˌ⋆⃟⊱๑⋆⃟⊱๑⋆⃟⊱━╯*
*▌*
*█░█░█░█░█░█░█░█░█*
  █ ▀ ▀ █ ▀ █ ▀ █ ▀ █ ▀ ▀ █ ▀ 
•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆*･ﾟ•*¨*•.¸¸☆
`
}
exports.help = help
