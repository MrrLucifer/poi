const animemenu = (prefix) => { 
	return `
✎═─⊱〘 𝐴𝑁𝐼𝑀𝐸 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}nekonime*
╰─⊱ *${prefix}wibu*
╰─⊱ *${prefix}wait*
╰─⊱ *${prefix}inu*
╰─⊱ *${prefix}pokemon*
╰─⊱ *${prefix}naruto*
╰─⊱ *${prefix}hinata*
╰─⊱ *${prefix}sasuke*
╰─⊱ *${prefix}sakura*
╰─⊱ *${prefix}boruto*
╰─⊱ *${prefix}minato*
╰─⊱ *${prefix}loli*
╰─⊱ *${prefix}loli2*
╰─⊱ *${prefix}rize*
╰─⊱ *${prefix}akira*
╰─⊱ *${prefix}itori*
╰─⊱ *${prefix}kurumi*
╰─⊱ *${prefix}miku*
║
✎═─⊱〘 𝐼𝐶𝐻𝐼 𝑀𝐸𝑁𝑈 〙⊰══`
}
exports.animemenu = animemenu