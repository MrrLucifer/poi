const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪══
║
╠belom ada iklan klo mo pasang iklan bilang di wa.me/629699715959
║
╚═〘  ICHI BOT 〙
`
}
exports.iklan = iklan